import{c as u}from"./storage-BEr3p68b.js";import{L as k}from"./liquid.browser-3Hwq0Zx0.js";const x=/\{\{link\s+"([^"]*)"\s*\}\}/g,v=/\{\{date\s+(@?[\w.]+)\s+"([^"]*)"\s*\}\}/g,y=/\{\{date\s+(@?[\w.]+)\s*\}\}/g,w=/\{\{num\s+(@?[\w.]+)\s*\}\}/g,R=/\{\{\{([\w.]+)\}\}\}/g,p=/\{\{#each\s+(@?[\w.]+)\s*\}\}/g,g="{{/each}}",S=/\{\{#when\s+(@?[\w.]+)\s+"([^"]*)"\s*\}\}([\s\S]*?)\{\{#else\}\}([\s\S]*?)\{\{\/when\}\}/g,M=/\{\{#when\s+(@?[\w.]+)\s+"([^"]*)"\s*\}\}([\s\S]*?)\{\{\/when\}\}/g,I=/\{\{@(\w+)\}\}/g,T=/\{%([^%]*)%\}/g;function L(e){return e.replace(/\{\{\s*this\.([\w.]+)\s*\}\}/g,"{{ item.$1 }}").replace(/\{\{\s*this\s*\}\}/g,"{{ item }}").replace(/\bthis\.([\w.]+)/g,"item.$1").replace(/\bthis\b/g,"item")}function b(e){let a="",t=0;for(;t<e.length;){p.lastIndex=t;const n=p.exec(e);if(!n){a+=e.slice(t);break}a+=e.slice(t,n.index);const s=n[1],o=n.index+n[0].length;let r=1,i=o,d=-1;for(;i<e.length;){p.lastIndex=i;const c=p.exec(e),l=e.indexOf(g,i);if(l===-1)break;if(c&&c.index<l)r+=1,i=c.index+c[0].length;else{if(r-=1,r===0){d=l;break}i=l+g.length}}if(d===-1){a+=e.slice(n.index);break}const h=e.slice(o,d),m=L(b(h));a+=`{% for item in ${s} %}${m}{% endfor %}`,t=d+g.length}return a}function z(e){let a=e;return a=a.replace(x,(t,n)=>`{{ "${n}" | link }}`),a=a.replace(v,(t,n,s)=>`{{ ${n} | date: "${s}" }}`),a=a.replace(y,(t,n)=>`{{ ${n} | date }}`),a=a.replace(w,(t,n)=>`{{ ${n} | num }}`),a=a.replace(R,(t,n)=>`{{ ${n} | raw }}`),a=b(a),a=a.replace(S,(t,n,s,o,r)=>`{% if ${n} == "${s}" %}${o}{% else %}${r}{% endif %}`),a=a.replace(M,(t,n,s,o)=>`{% if ${n} == "${s}" %}${o}{% endif %}`),a=a.replace(I,(t,n)=>`{{ vars.${n} }}`),a=a.replace(T,(t,n)=>`{%${n.replace(/@(\w+)/g,"vars.$1")}%}`),a}const P=90*1024;function A(e){return new TextEncoder().encode(JSON.stringify(e)).length}async function C(e){const a=await e.sync.get(["rules","templates","hostSkipList"]);await e.local.set({...a,pj_storage_area:"local"}),await e.sync.clear()}async function U(e){const a={syncMigrated:0,localMigrated:0};for(const t of["sync","local"]){const n=e[t];let s;try{s=await n.get("rules")}catch{continue}const o=s.rules;if(!Array.isArray(o))continue;let r=0;const i=o.map(d=>{if(d&&typeof d=="object"&&"enabled"in d&&!("active"in d)){r+=1;const{enabled:h,...m}=d;return{...m,active:h}}return d});r>0&&(await n.set({rules:i}),t==="sync"?a.syncMigrated=r:a.localMigrated=r)}return a}async function E(e){const a=await e.getTemplates(),t=new k,n={},s=[],o=[];for(const[r,i]of Object.entries(a)){const d=z(i);try{t.parse(d),n[r]=d,s.push(r)}catch{o.push(r)}}return o.length>0?{ok:!1,migrated:[],failed:o}:(await e.setTemplates(n),await e.setSchemaVersion(2),e.setMigratedList&&s.length>0&&await e.setMigratedList(s),{ok:!0,migrated:s,failed:[]})}const j=`{%- comment -%}
  Freshet starter — Service Health page. Liquid syntax.
  Bundled rule: \`mattaltermatt.github.io\` / \`/freshet/examples/services/*\`
  Bundled rule var: \`env\` → renders the env chip in the header AND the top-strip.
  Try it: https://mattaltermatt.github.io/freshet/examples/services/payments.json
{%- endcomment -%}
<div class="sh">
  <header class="sh__head">
    <div class="sh__brand">
      <span class="sh__env" data-env="{{ vars.env }}">{{ vars.env | default: "live" }}</span>
      <h1 class="sh__title">{{ name }}</h1>
      <span class="sh__status sh__status--{{ status }}">
        <span class="sh__dot"></span>
        {% if status == "operational" %}All systems operational{% endif %}
        {% if status == "degraded" %}Degraded performance{% endif %}
        {% if status == "down" %}Major outage{% endif %}
      </span>
    </div>
    {% if description != blank %}<p class="sh__desc">{{ description }}</p>{% endif %}
  </header>

  <section class="sh__row">
    <div class="sh__metric">
      <span class="sh__metric-label">Uptime · 30d</span>
      <span class="sh__metric-value">{{ uptime30d }}<span class="sh__metric-unit">%</span></span>
    </div>
    <div class="sh__metric">
      <span class="sh__metric-label">Last incident</span>
      <span class="sh__metric-value sh__metric-value--ts">{{ lastIncidentAt | date }}</span>
    </div>
    <div class="sh__metric sh__metric--oncall">
      <span class="sh__metric-label">On-call</span>
      {%- comment -%} URL-FROM-ID demo (1/3): the JSON only carries \`oncall.handle\`
      ("@priya"). The template builds the canonical pager URL by stripping the @
      and slotting it into our org's known pattern. No more hunting bookmarks. {%- endcomment -%}
      <span class="sh__metric-value">
        <a href="https://oncall.example.com/u/{{ oncall.handle | remove: '@' }}" class="sh__oncall">
          {{ oncall.name }} <span class="sh__oncall-handle">{{ oncall.handle }}</span>
        </a>
      </span>
    </div>
  </section>

  <section class="sh__deps">
    <h2 class="sh__h2">Dependencies</h2>
    <ul class="sh__deps-list">
      {% for dep in dependencies %}
      <li class="sh__dep sh__dep--{{ dep.status }}">
        <span class="sh__dep-dot"></span>
        <span class="sh__dep-name">{{ dep.name }}</span>
        <span class="sh__dep-status">{{ dep.status }}</span>
      </li>
      {% endfor %}
    </ul>
  </section>

  <section class="sh__incidents">
    <h2 class="sh__h2">Recent incidents</h2>
    {%- comment -%} URL-FROM-ID demo (2/3): the JSON has no \`url\` on each
    incident — just an \`id\` like "INC-2026-001". The template constructs the
    canonical URL from the ID + our known incident-page route. Click → Freshet
    matches the incident-detail rule and renders the next page too. {%- endcomment -%}
    <ul class="sh__inc-list">
      {% for inc in recentIncidents %}
      <li class="sh__inc sh__inc--{{ inc.severity }}">
        <a class="sh__inc-link" href="https://mattaltermatt.github.io/freshet/examples/incidents/{{ inc.id }}.json">
          <span class="sh__inc-sev">{{ inc.severity }}</span>
          <span class="sh__inc-title">{{ inc.title }}</span>
          <span class="sh__inc-meta">
            {% if inc.resolvedAt == nil %}
              <span class="sh__inc-open">● Open</span>
            {% else %}
              <span class="sh__inc-resolved">Resolved {{ inc.resolvedAt | date: "MM/dd HH:mm" }}</span>
            {% endif %}
            <span class="sh__inc-when">opened {{ inc.openedAt | date: "MM/dd HH:mm" }}</span>
          </span>
        </a>
      </li>
      {% endfor %}
    </ul>
  </section>

  <footer class="sh__foot">
    {%- comment -%} URL-FROM-ID demo (3/3): JSON has just \`repo: "example/payments-service"\`.
    Runbook + dashboard URLs follow the org's conventions, slotted from \`slug\`. {%- endcomment -%}
    <a href="https://runbooks.example.com/{{ slug }}">📖 Runbook</a>
    <a href="https://grafana.example.com/d/{{ slug }}-overview">📈 Dashboard</a>
    {% if repo != blank %}<a href="https://github.com/{{ repo }}">📦 Repo</a>{% endif %}
  </footer>
</div>

<style>
  /* Light theme (default) */
  body { background:#f6f8fa; margin:0; padding:24px; font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif; color:#1f2328; }
  .sh { max-width:880px; margin:0 auto; background:#ffffff; border:1px solid #d0d7de; border-radius:10px; overflow:hidden; box-shadow:0 1px 3px rgba(0,0,0,.04); }
  .sh__head { padding:24px; border-bottom:1px solid #d0d7de; }
  .sh__brand { display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
  .sh__env { background:#0969da; color:#fff; font:600 10px/1 ui-monospace,Menlo,monospace; padding:4px 8px; border-radius:4px; letter-spacing:.08em; text-transform:uppercase; }
  .sh__env[data-env="production"] { background:#cf222e; }
  .sh__env[data-env="staging"]    { background:#9a6700; }
  .sh__title { margin:0; font-size:22px; font-weight:600; flex:1 1 auto; color:#1f2328; }
  .sh__status { display:inline-flex; align-items:center; gap:6px; font:600 12px/1.4 ui-monospace,Menlo,monospace; padding:4px 10px; border-radius:999px; text-transform:uppercase; letter-spacing:.04em; }
  .sh__status--operational { background:rgba(26,127,55,.12); color:#1a7f37; }
  .sh__status--degraded    { background:rgba(154,103,0,.14); color:#9a6700; }
  .sh__status--down        { background:rgba(207,34,46,.12); color:#cf222e; }
  .sh__dot { width:8px; height:8px; border-radius:50%; background:currentColor; }
  .sh__desc { margin:12px 0 0; color:#656d76; }

  .sh__row { display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:#d0d7de; border-bottom:1px solid #d0d7de; }
  .sh__metric { background:#ffffff; padding:18px 24px; display:flex; flex-direction:column; gap:6px; }
  .sh__metric-label { font:600 10px/1 ui-monospace,Menlo,monospace; color:#656d76; text-transform:uppercase; letter-spacing:.06em; }
  .sh__metric-value { font:600 24px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; color:#1f2328; }
  .sh__metric-value--ts { font-size:14px; color:#656d76; font-weight:500; }
  .sh__metric-unit { color:#656d76; font-size:14px; margin-left:2px; }
  .sh__oncall { color:#0969da; text-decoration:none; font-size:14px; font-weight:500; }
  .sh__oncall:hover { text-decoration:underline; }
  .sh__oncall-handle { color:#656d76; font-family:ui-monospace,Menlo,monospace; font-size:12px; margin-left:4px; }

  .sh__h2 { margin:0 0 12px; font-size:13px; font-weight:600; color:#656d76; text-transform:uppercase; letter-spacing:.06em; }

  .sh__deps { padding:20px 24px; border-bottom:1px solid #d0d7de; }
  .sh__deps-list { list-style:none; margin:0; padding:0; display:grid; grid-template-columns:repeat(2,1fr); gap:8px 16px; }
  .sh__dep { display:flex; align-items:center; gap:10px; padding:8px 12px; background:#f6f8fa; border:1px solid #d0d7de; border-radius:6px; font-size:13px; }
  .sh__dep-dot { width:8px; height:8px; border-radius:50%; flex:none; }
  .sh__dep--operational .sh__dep-dot { background:#1a7f37; }
  .sh__dep--degraded    .sh__dep-dot { background:#9a6700; }
  .sh__dep--down        .sh__dep-dot { background:#cf222e; }
  .sh__dep-name { flex:1 1 auto; color:#1f2328; }
  .sh__dep-status { font:600 10px/1 ui-monospace,Menlo,monospace; text-transform:uppercase; letter-spacing:.06em; color:#656d76; }

  .sh__incidents { padding:20px 24px; border-bottom:1px solid #d0d7de; }
  .sh__inc-list { list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:6px; }
  .sh__inc-link { display:grid; grid-template-columns:auto 1fr auto; gap:12px; align-items:center; padding:12px 14px; background:#f6f8fa; border:1px solid #d0d7de; border-radius:6px; text-decoration:none; color:inherit; transition:border-color 120ms ease, background 120ms ease; }
  .sh__inc-link:hover { border-color:#0969da; background:#ffffff; }
  .sh__inc-sev { font:700 10px/1 ui-monospace,Menlo,monospace; text-transform:uppercase; letter-spacing:.08em; padding:4px 8px; border-radius:4px; background:rgba(154,103,0,.16); color:#9a6700; }
  .sh__inc--sev-1 .sh__inc-sev { background:rgba(207,34,46,.14); color:#cf222e; }
  .sh__inc--sev-3 .sh__inc-sev { background:rgba(101,109,118,.14); color:#656d76; }
  .sh__inc-title { font-size:14px; color:#1f2328; font-weight:500; }
  .sh__inc-meta { display:flex; flex-direction:column; align-items:flex-end; gap:2px; font-size:11px; color:#656d76; }
  .sh__inc-open { color:#cf222e; font-weight:600; }
  .sh__inc-resolved { color:#1a7f37; }

  .sh__foot { display:flex; gap:18px; padding:14px 24px; background:#f6f8fa; }
  .sh__foot a { color:#0969da; text-decoration:none; font-size:13px; }
  .sh__foot a:hover { text-decoration:underline; }

  /* Dark theme — applied when Freshet sets data-theme="dark" on <html>. */
  [data-theme="dark"] body { background:#0d1117; color:#e6edf3; }
  [data-theme="dark"] .sh { background:#161b22; border-color:#30363d; box-shadow:none; }
  [data-theme="dark"] .sh__head { border-bottom-color:#30363d; }
  [data-theme="dark"] .sh__env { background:#1f6feb; }
  [data-theme="dark"] .sh__env[data-env="production"] { background:#da3633; }
  [data-theme="dark"] .sh__env[data-env="staging"]    { background:#bf8700; }
  [data-theme="dark"] .sh__title { color:#e6edf3; }
  [data-theme="dark"] .sh__status--operational { background:rgba(35,134,54,.15); color:#3fb950; }
  [data-theme="dark"] .sh__status--degraded    { background:rgba(210,153,34,.18); color:#d29922; }
  [data-theme="dark"] .sh__status--down        { background:rgba(248,81,73,.18); color:#f85149; }
  [data-theme="dark"] .sh__desc { color:#8d96a0; }
  [data-theme="dark"] .sh__row { background:#30363d; border-bottom-color:#30363d; }
  [data-theme="dark"] .sh__metric { background:#161b22; }
  [data-theme="dark"] .sh__metric-label { color:#8d96a0; }
  [data-theme="dark"] .sh__metric-value { color:#e6edf3; }
  [data-theme="dark"] .sh__metric-value--ts { color:#8d96a0; }
  [data-theme="dark"] .sh__metric-unit { color:#8d96a0; }
  [data-theme="dark"] .sh__oncall { color:#2f81f7; }
  [data-theme="dark"] .sh__oncall-handle { color:#8d96a0; }
  [data-theme="dark"] .sh__h2 { color:#8d96a0; }
  [data-theme="dark"] .sh__deps { border-bottom-color:#30363d; }
  [data-theme="dark"] .sh__dep { background:#0d1117; border-color:#30363d; }
  [data-theme="dark"] .sh__dep-name { color:#e6edf3; }
  [data-theme="dark"] .sh__dep-status { color:#8d96a0; }
  [data-theme="dark"] .sh__dep--operational .sh__dep-dot { background:#3fb950; }
  [data-theme="dark"] .sh__dep--degraded    .sh__dep-dot { background:#d29922; }
  [data-theme="dark"] .sh__dep--down        .sh__dep-dot { background:#f85149; }
  [data-theme="dark"] .sh__incidents { border-bottom-color:#30363d; }
  [data-theme="dark"] .sh__inc-link { background:#0d1117; border-color:#30363d; }
  [data-theme="dark"] .sh__inc-link:hover { border-color:#2f81f7; background:#161b22; }
  [data-theme="dark"] .sh__inc-sev { background:rgba(210,153,34,.18); color:#d29922; }
  [data-theme="dark"] .sh__inc--sev-1 .sh__inc-sev { background:rgba(248,81,73,.2); color:#f85149; }
  [data-theme="dark"] .sh__inc--sev-3 .sh__inc-sev { background:rgba(125,133,144,.2); color:#8d96a0; }
  [data-theme="dark"] .sh__inc-title { color:#e6edf3; }
  [data-theme="dark"] .sh__inc-meta { color:#8d96a0; }
  [data-theme="dark"] .sh__inc-open { color:#f85149; }
  [data-theme="dark"] .sh__inc-resolved { color:#3fb950; }
  [data-theme="dark"] .sh__foot { background:#0d1117; }
  [data-theme="dark"] .sh__foot a { color:#2f81f7; }
</style>
`,O=`{%- comment -%}
  Freshet starter — Incident Detail page. Liquid syntax.
  Bundled rule: \`mattaltermatt.github.io\` / \`/freshet/examples/incidents/*\`
  Try it: https://mattaltermatt.github.io/freshet/examples/incidents/INC-2026-001.json
  Reached by clicking an incident row on the rendered Service Health page.
{%- endcomment -%}
<div class="inc">
  <header class="inc__head">
    {%- comment -%} URL-FROM-ID demo (1/3): the JSON's \`service\` block has no \`url\`,
    just \`slug: "payments"\`. Construct the canonical service URL from the slug
    + the org's known service-page route. {%- endcomment -%}
    <div class="inc__breadcrumb">
      <a href="https://mattaltermatt.github.io/freshet/examples/services/{{ service.slug }}.json">{{ service.name }}</a>
      <span class="inc__crumb-sep">›</span>
      <span class="inc__id">{{ id }}</span>
    </div>
    <h1 class="inc__title">{{ title }}</h1>
    <div class="inc__chips">
      <span class="inc__chip inc__chip--sev inc__chip--{{ severity }}">{{ severity }}</span>
      <span class="inc__chip inc__chip--status inc__chip--status-{{ status }}">
        <span class="inc__pulse"></span>{{ status }}
      </span>
      <span class="inc__chip inc__chip--time">opened {{ openedAt | date }}</span>
      {% if resolvedAt != nil %}<span class="inc__chip inc__chip--time">resolved {{ resolvedAt | date }}</span>{% endif %}
    </div>
  </header>

  <section class="inc__cards">
    <div class="inc__card">
      <h2 class="inc__h2">Summary</h2>
      <p>{{ summary }}</p>
    </div>
    <div class="inc__card inc__card--impact">
      <h2 class="inc__h2">Impact</h2>
      <p>{{ impact }}</p>
    </div>
    <div class="inc__card inc__card--meta">
      <dl class="inc__meta">
        {%- comment -%} URL-FROM-ID demo (2/3): on-call pager URL built from \`oncall.handle\`
        (e.g. "@priya"), stripping the @. {%- endcomment -%}
        <dt>On-call</dt>
        <dd>
          <a href="https://oncall.example.com/u/{{ oncall.handle | remove: '@' }}">{{ oncall.name }}</a>
          <span class="inc__handle">{{ oncall.handle }}</span>
        </dd>
        <dt>Service</dt>
        <dd><a href="https://mattaltermatt.github.io/freshet/examples/services/{{ service.slug }}.json">{{ service.name }}</a></dd>
        <dt>Severity</dt>
        <dd>{{ severity }}</dd>
      </dl>
    </div>
  </section>

  <section class="inc__timeline">
    <h2 class="inc__h2">Timeline</h2>
    <ol class="inc__events">
      {% for ev in timeline %}
      <li class="inc__event inc__event--{{ ev.kind }}">
        <span class="inc__event-time">{{ ev.at | date: "HH:mm" }}</span>
        <span class="inc__event-rail" aria-hidden="true"></span>
        <div class="inc__event-body">
          <div class="inc__event-author">
            <span class="inc__event-kind">{{ ev.kind }}</span>
            <span class="inc__event-who">{{ ev.author }}</span>
          </div>
          <p class="inc__event-msg">{{ ev.message }}</p>
        </div>
      </li>
      {% endfor %}
    </ol>
  </section>

  {% if relatedIncidents != blank and relatedIncidents.size > 0 %}
  <section class="inc__related">
    <h2 class="inc__h2">Related incidents</h2>
    {%- comment -%} URL-FROM-ID demo (3/3): related incidents JSON has only
    \`id\` + \`title\` per item. The href below builds the canonical incident URL
    from the ID, demonstrating "your random GUIDs become first-class navigation
    targets" — no more hunting bookmarks for endpoint URL patterns. {%- endcomment -%}
    <ul>
      {% for r in relatedIncidents %}
      <li>
        <a href="https://mattaltermatt.github.io/freshet/examples/incidents/{{ r.id }}.json">
          <span class="inc__rel-id">{{ r.id }}</span> {{ r.title }}
        </a>
      </li>
      {% endfor %}
    </ul>
  </section>
  {% endif %}
</div>

<style>
  /* Light theme (default) */
  body { background:#f6f8fa; margin:0; padding:24px; font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif; color:#1f2328; }
  .inc { max-width:880px; margin:0 auto; background:#ffffff; border:1px solid #d0d7de; border-radius:10px; overflow:hidden; box-shadow:0 1px 3px rgba(0,0,0,.04); }
  .inc__head { padding:24px; border-bottom:1px solid #d0d7de; }
  .inc__breadcrumb { font-size:12px; color:#656d76; display:flex; align-items:center; gap:6px; margin-bottom:8px; }
  .inc__breadcrumb a { color:#0969da; text-decoration:none; }
  .inc__breadcrumb a:hover { text-decoration:underline; }
  .inc__crumb-sep { color:#d0d7de; }
  .inc__id { font-family:ui-monospace,Menlo,monospace; color:#656d76; font-weight:600; letter-spacing:.04em; }
  .inc__title { margin:0 0 14px; font-size:22px; font-weight:600; line-height:1.3; color:#1f2328; }
  .inc__chips { display:flex; flex-wrap:wrap; gap:8px; }
  .inc__chip { font:600 11px/1 ui-monospace,Menlo,monospace; padding:6px 10px; border-radius:999px; text-transform:uppercase; letter-spacing:.04em; display:inline-flex; align-items:center; gap:6px; }
  .inc__chip--sev-1 { background:rgba(207,34,46,.16); color:#cf222e; }
  .inc__chip--sev-2 { background:rgba(154,103,0,.18); color:#9a6700; }
  .inc__chip--sev-3 { background:rgba(101,109,118,.16); color:#656d76; }
  .inc__chip--status-investigating { background:rgba(207,34,46,.14); color:#cf222e; }
  .inc__chip--status-identified    { background:rgba(154,103,0,.14); color:#9a6700; }
  .inc__chip--status-monitoring    { background:rgba(9,105,218,.14); color:#0969da; }
  .inc__chip--status-resolved      { background:rgba(26,127,55,.14); color:#1a7f37; }
  .inc__chip--time { background:#f6f8fa; color:#656d76; border:1px solid #d0d7de; text-transform:none; letter-spacing:0; }
  .inc__pulse { width:8px; height:8px; border-radius:50%; background:currentColor; box-shadow:0 0 0 0 currentColor; animation:inc-pulse 1.6s ease-out infinite; }
  @keyframes inc-pulse { 0% { box-shadow:0 0 0 0 currentColor; } 70% { box-shadow:0 0 0 6px rgba(0,0,0,0); } 100% { box-shadow:0 0 0 0 rgba(0,0,0,0); } }
  .inc__chip--status-resolved .inc__pulse { animation:none; }

  .inc__cards { display:grid; grid-template-columns:1fr 1fr; gap:1px; background:#d0d7de; border-bottom:1px solid #d0d7de; }
  .inc__card { background:#ffffff; padding:18px 24px; }
  .inc__card--meta { grid-column:1 / -1; }
  .inc__card p { margin:0; color:#1f2328; }
  .inc__h2 { margin:0 0 10px; font:600 11px/1 ui-monospace,Menlo,monospace; color:#656d76; text-transform:uppercase; letter-spacing:.06em; }
  .inc__meta { display:grid; grid-template-columns:auto 1fr; gap:6px 16px; margin:0; font-size:13px; }
  .inc__meta dt { color:#656d76; font-weight:500; }
  .inc__meta dd { margin:0; color:#1f2328; }
  .inc__meta a { color:#0969da; text-decoration:none; }
  .inc__meta a:hover { text-decoration:underline; }
  .inc__handle { font-family:ui-monospace,Menlo,monospace; color:#656d76; font-size:12px; margin-left:4px; }

  .inc__timeline { padding:20px 24px; border-bottom:1px solid #d0d7de; }
  .inc__events { list-style:none; margin:0; padding:0; }
  .inc__event { display:grid; grid-template-columns:60px 16px 1fr; gap:8px; padding:10px 0; position:relative; }
  .inc__event-time { font:600 11px/1.4 ui-monospace,Menlo,monospace; color:#656d76; padding-top:2px; }
  .inc__event-rail { position:relative; }
  .inc__event-rail::before { content:""; position:absolute; left:7px; top:6px; bottom:-10px; width:2px; background:#d0d7de; }
  .inc__event:last-child .inc__event-rail::before { display:none; }
  .inc__event-rail::after { content:""; position:absolute; left:3px; top:4px; width:10px; height:10px; border-radius:50%; background:#d0d7de; border:2px solid #ffffff; }
  .inc__event--alert  .inc__event-rail::after { background:#cf222e; }
  .inc__event--ack    .inc__event-rail::after { background:#9a6700; }
  .inc__event--update .inc__event-rail::after { background:#0969da; }
  .inc__event--deploy .inc__event-rail::after { background:#1a7f37; }
  .inc__event-body { background:#f6f8fa; border:1px solid #d0d7de; border-radius:6px; padding:10px 12px; }
  .inc__event-author { display:flex; align-items:center; gap:8px; margin-bottom:4px; }
  .inc__event-kind { font:600 9px/1 ui-monospace,Menlo,monospace; text-transform:uppercase; letter-spacing:.08em; padding:3px 6px; border-radius:3px; background:#d0d7de; color:#656d76; }
  .inc__event--alert  .inc__event-kind { background:rgba(207,34,46,.16); color:#cf222e; }
  .inc__event--ack    .inc__event-kind { background:rgba(154,103,0,.18); color:#9a6700; }
  .inc__event--update .inc__event-kind { background:rgba(9,105,218,.16); color:#0969da; }
  .inc__event--deploy .inc__event-kind { background:rgba(26,127,55,.16); color:#1a7f37; }
  .inc__event-who { font-size:12px; color:#656d76; font-family:ui-monospace,Menlo,monospace; }
  .inc__event-msg { margin:0; font-size:13px; color:#1f2328; line-height:1.5; }

  .inc__related { padding:18px 24px; }
  .inc__related ul { list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:6px; }
  .inc__related a { color:#0969da; text-decoration:none; font-size:13px; display:flex; gap:10px; align-items:baseline; }
  .inc__related a:hover { text-decoration:underline; }
  .inc__rel-id { font-family:ui-monospace,Menlo,monospace; color:#656d76; font-weight:600; font-size:11px; }

  /* Dark theme — applied when Freshet sets data-theme="dark" on <html>. */
  [data-theme="dark"] body { background:#0d1117; color:#e6edf3; }
  [data-theme="dark"] .inc { background:#161b22; border-color:#30363d; box-shadow:none; }
  [data-theme="dark"] .inc__head { border-bottom-color:#30363d; }
  [data-theme="dark"] .inc__breadcrumb { color:#8d96a0; }
  [data-theme="dark"] .inc__breadcrumb a { color:#2f81f7; }
  [data-theme="dark"] .inc__crumb-sep { color:#30363d; }
  [data-theme="dark"] .inc__id { color:#8d96a0; }
  [data-theme="dark"] .inc__title { color:#e6edf3; }
  [data-theme="dark"] .inc__chip--sev-1 { background:rgba(248,81,73,.22); color:#f85149; }
  [data-theme="dark"] .inc__chip--sev-2 { background:rgba(210,153,34,.22); color:#d29922; }
  [data-theme="dark"] .inc__chip--sev-3 { background:rgba(125,133,144,.2);  color:#8d96a0; }
  [data-theme="dark"] .inc__chip--status-investigating { background:rgba(248,81,73,.18); color:#f85149; }
  [data-theme="dark"] .inc__chip--status-identified    { background:rgba(210,153,34,.18); color:#d29922; }
  [data-theme="dark"] .inc__chip--status-monitoring    { background:rgba(47,129,247,.18); color:#2f81f7; }
  [data-theme="dark"] .inc__chip--status-resolved      { background:rgba(35,134,54,.18); color:#3fb950; }
  [data-theme="dark"] .inc__chip--time { background:#0d1117; color:#8d96a0; border-color:#30363d; }
  [data-theme="dark"] .inc__cards { background:#30363d; border-bottom-color:#30363d; }
  [data-theme="dark"] .inc__card { background:#161b22; }
  [data-theme="dark"] .inc__card p { color:#e6edf3; }
  [data-theme="dark"] .inc__h2 { color:#8d96a0; }
  [data-theme="dark"] .inc__meta dt { color:#8d96a0; }
  [data-theme="dark"] .inc__meta dd { color:#e6edf3; }
  [data-theme="dark"] .inc__meta a { color:#2f81f7; }
  [data-theme="dark"] .inc__handle { color:#8d96a0; }
  [data-theme="dark"] .inc__timeline { border-bottom-color:#30363d; }
  [data-theme="dark"] .inc__event-time { color:#8d96a0; }
  [data-theme="dark"] .inc__event-rail::before { background:#30363d; }
  [data-theme="dark"] .inc__event-rail::after { background:#30363d; border-color:#161b22; }
  [data-theme="dark"] .inc__event--alert  .inc__event-rail::after { background:#f85149; }
  [data-theme="dark"] .inc__event--ack    .inc__event-rail::after { background:#d29922; }
  [data-theme="dark"] .inc__event--update .inc__event-rail::after { background:#2f81f7; }
  [data-theme="dark"] .inc__event--deploy .inc__event-rail::after { background:#3fb950; }
  [data-theme="dark"] .inc__event-body { background:#0d1117; border-color:#30363d; }
  [data-theme="dark"] .inc__event-kind { background:#30363d; color:#8d96a0; }
  [data-theme="dark"] .inc__event--alert  .inc__event-kind { background:rgba(248,81,73,.22); color:#f85149; }
  [data-theme="dark"] .inc__event--ack    .inc__event-kind { background:rgba(210,153,34,.22); color:#d29922; }
  [data-theme="dark"] .inc__event--update .inc__event-kind { background:rgba(47,129,247,.22); color:#2f81f7; }
  [data-theme="dark"] .inc__event--deploy .inc__event-kind { background:rgba(35,134,54,.22); color:#3fb950; }
  [data-theme="dark"] .inc__event-who { color:#8d96a0; }
  [data-theme="dark"] .inc__event-msg { color:#e6edf3; }
  [data-theme="dark"] .inc__related a { color:#2f81f7; }
  [data-theme="dark"] .inc__rel-id { color:#8d96a0; }
</style>
`,F=`{%- comment -%}
  Freshet starter — "GitHub repo" card. Liquid syntax.
  Bundled rule: \`api.github.com\` / \`/repos/*/*\`  (inactive by default)
  Try it: activate the rule in Rules tab, then visit
  https://api.github.com/repos/facebook/react
{%- endcomment -%}
<div class="gh">
  <header class="gh__head">
    <img class="gh__avatar" src="{{ owner.avatar_url }}" alt="{{ owner.login }} avatar" />
    <div class="gh__heading">
      <h1 class="gh__title"><a href="{{ html_url }}">{{ full_name }}</a></h1>
      {% if description != blank %}<p class="gh__desc">{{ description }}</p>{% endif %}
      <div class="gh__chips">
        {% if archived %}
          <span class="gh__chip gh__chip--archived"><span class="gh__dot"></span>Archived</span>
        {% else %}
          <span class="gh__chip gh__chip--active"><span class="gh__dot gh__dot--pulse"></span>Active</span>
        {% endif %}
        {% if language != blank %}<span class="gh__chip gh__chip--lang" data-lang="{{ language }}"><span class="gh__lang-dot"></span>{{ language }}</span>{% endif %}
        {% if license.spdx_id != blank %}<span class="gh__chip gh__chip--meta">⚖ {{ license.spdx_id }}</span>{% endif %}
        <span class="gh__chip gh__chip--meta">⎇ {{ default_branch }}</span>
      </div>
      {% if homepage != blank %}<p class="gh__home">→ <a href="{{ homepage }}">{{ homepage }}</a></p>{% endif %}
    </div>
  </header>

  <section class="gh__stats">
    <div class="gh__stat">
      <span class="gh__stat-icon">⭐</span>
      <span class="gh__stat-num">{{ stargazers_count | num }}</span>
      <span class="gh__stat-label">Stars</span>
    </div>
    <div class="gh__stat">
      <span class="gh__stat-icon">🍴</span>
      <span class="gh__stat-num">{{ forks_count | num }}</span>
      <span class="gh__stat-label">Forks</span>
    </div>
    <div class="gh__stat">
      <span class="gh__stat-icon">👁</span>
      <span class="gh__stat-num">{{ subscribers_count | num }}</span>
      <span class="gh__stat-label">Watchers</span>
    </div>
    <div class="gh__stat">
      <span class="gh__stat-icon">🐛</span>
      <span class="gh__stat-num">{{ open_issues_count | num }}</span>
      <span class="gh__stat-label">Open Issues</span>
    </div>
  </section>

  {% if topics.size > 0 %}
  <section class="gh__topics">
    <h2 class="gh__h2">Topics</h2>
    <div class="gh__topic-list">
      {% for topic in topics %}<span class="gh__topic">{{ topic }}</span>{% endfor %}
    </div>
  </section>
  {% endif %}

  <section class="gh__dates">
    <dl>
      <dt>Created</dt><dd>{{ created_at | date: "yyyy-MM-dd" }}</dd>
      <dt>Last push</dt><dd>{{ pushed_at | date: "yyyy-MM-dd HH:mm" }}</dd>
    </dl>
  </section>

  {%- comment -%} URL-FROM-ID demo: GitHub's API returns \`full_name\` like
  "facebook/react". The footer below builds the canonical web-app URLs for
  Issues/PRs/Releases/Discussions from that one field — no hunting bookmarks. {%- endcomment -%}
  <footer class="gh__foot">
    <a href="https://github.com/{{ full_name }}/issues">🐛 Issues</a>
    <a href="https://github.com/{{ full_name }}/pulls">⇄ Pull requests</a>
    <a href="https://github.com/{{ full_name }}/releases">🚀 Releases</a>
    <a href="https://github.com/{{ full_name }}/discussions">💬 Discussions</a>
  </footer>
</div>

<style>
  /* Light theme (default) */
  body { background:#f6f8fa; margin:0; padding:24px; font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif; color:#1f2328; }
  .gh { max-width:760px; margin:0 auto; background:#ffffff; border:1px solid #d0d7de; border-radius:12px; overflow:hidden; box-shadow:0 1px 3px rgba(0,0,0,.04); }

  .gh__head { display:grid; grid-template-columns:auto 1fr; gap:20px; padding:24px; border-bottom:1px solid #d0d7de; align-items:start; }
  .gh__avatar { width:80px; height:80px; border-radius:50%; flex-shrink:0; border:1px solid #d0d7de; }
  .gh__heading { min-width:0; }
  .gh__title { margin:0 0 6px; font-size:22px; font-weight:600; line-height:1.2; }
  .gh__title a { color:#0969da; text-decoration:none; }
  .gh__title a:hover { text-decoration:underline; }
  .gh__desc { margin:0 0 12px; color:#656d76; font-size:14px; line-height:1.5; }
  .gh__chips { display:flex; flex-wrap:wrap; gap:6px; margin-bottom:8px; }
  .gh__chip { display:inline-flex; align-items:center; gap:6px; padding:4px 10px; border-radius:999px; font:600 11px/1 ui-monospace,Menlo,monospace; text-transform:uppercase; letter-spacing:.04em; }
  .gh__chip--active   { background:rgba(26,127,55,.12); color:#1a7f37; }
  .gh__chip--archived { background:rgba(207,34,46,.12); color:#cf222e; }
  .gh__chip--lang     { background:#f6f8fa; color:#1f2328; border:1px solid #d0d7de; text-transform:none; letter-spacing:0; }
  .gh__chip--meta     { background:#f6f8fa; color:#656d76; border:1px solid #d0d7de; text-transform:none; letter-spacing:0; font-weight:500; }
  .gh__dot { width:7px; height:7px; border-radius:50%; background:currentColor; }
  .gh__dot--pulse { box-shadow:0 0 0 0 currentColor; animation:gh-pulse 1.8s ease-out infinite; }
  @keyframes gh-pulse { 0% { box-shadow:0 0 0 0 currentColor; } 70% { box-shadow:0 0 0 6px rgba(0,0,0,0); } 100% { box-shadow:0 0 0 0 rgba(0,0,0,0); } }
  .gh__lang-dot { width:10px; height:10px; border-radius:50%; background:#959da5; flex:none; }
  .gh__chip--lang[data-lang="JavaScript"] .gh__lang-dot { background:#f1e05a; }
  .gh__chip--lang[data-lang="TypeScript"] .gh__lang-dot { background:#3178c6; }
  .gh__chip--lang[data-lang="Python"]     .gh__lang-dot { background:#3572a5; }
  .gh__chip--lang[data-lang="Ruby"]       .gh__lang-dot { background:#701516; }
  .gh__chip--lang[data-lang="Go"]         .gh__lang-dot { background:#00add8; }
  .gh__chip--lang[data-lang="Rust"]       .gh__lang-dot { background:#dea584; }
  .gh__chip--lang[data-lang="Java"]       .gh__lang-dot { background:#b07219; }
  .gh__chip--lang[data-lang="C++"]        .gh__lang-dot { background:#f34b7d; }
  .gh__chip--lang[data-lang="C"]          .gh__lang-dot { background:#555555; }
  .gh__chip--lang[data-lang="C#"]         .gh__lang-dot { background:#178600; }
  .gh__chip--lang[data-lang="Swift"]      .gh__lang-dot { background:#ffac45; }
  .gh__chip--lang[data-lang="Kotlin"]     .gh__lang-dot { background:#a97bff; }
  .gh__chip--lang[data-lang="PHP"]        .gh__lang-dot { background:#4f5d95; }
  .gh__chip--lang[data-lang="HTML"]       .gh__lang-dot { background:#e34c26; }
  .gh__chip--lang[data-lang="CSS"]        .gh__lang-dot { background:#563d7c; }
  .gh__chip--lang[data-lang="Shell"]      .gh__lang-dot { background:#89e051; }
  .gh__chip--lang[data-lang="Vue"]        .gh__lang-dot { background:#41b883; }
  .gh__chip--lang[data-lang="Elixir"]     .gh__lang-dot { background:#6e4a7e; }
  .gh__home { margin:6px 0 0; font-size:13px; }
  .gh__home a { color:#0969da; text-decoration:none; }
  .gh__home a:hover { text-decoration:underline; }

  .gh__stats { display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:#d0d7de; border-bottom:1px solid #d0d7de; }
  .gh__stat { background:#ffffff; padding:18px 12px; display:flex; flex-direction:column; align-items:center; gap:4px; transition:background 120ms ease; }
  .gh__stat:hover { background:#f6f8fa; }
  .gh__stat-icon { font-size:20px; line-height:1; }
  .gh__stat-num { font:600 22px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; color:#1f2328; font-variant-numeric:tabular-nums; }
  .gh__stat-label { font:600 10px/1 ui-monospace,Menlo,monospace; color:#656d76; text-transform:uppercase; letter-spacing:.06em; }

  .gh__h2 { margin:0 0 10px; font:600 11px/1 ui-monospace,Menlo,monospace; color:#656d76; text-transform:uppercase; letter-spacing:.06em; }
  .gh__topics { padding:18px 24px; border-bottom:1px solid #d0d7de; }
  .gh__topic-list { display:flex; flex-wrap:wrap; gap:6px; }
  .gh__topic { background:rgba(9,105,218,.1); color:#0969da; font-size:12px; padding:4px 10px; border-radius:999px; }

  .gh__dates { padding:14px 24px; border-bottom:1px solid #d0d7de; }
  .gh__dates dl { display:grid; grid-template-columns:auto 1fr auto 1fr; gap:6px 16px; margin:0; font-size:13px; }
  .gh__dates dt { color:#656d76; font-weight:500; }
  .gh__dates dd { margin:0; color:#1f2328; font-family:ui-monospace,Menlo,monospace; font-size:12px; }

  .gh__foot { display:flex; gap:18px; padding:14px 24px; background:#f6f8fa; flex-wrap:wrap; }
  .gh__foot a { color:#0969da; text-decoration:none; font-size:13px; }
  .gh__foot a:hover { text-decoration:underline; }

  /* Dark theme — applied when Freshet sets data-theme="dark" on <html>. */
  [data-theme="dark"] body { background:#0d1117; color:#e6edf3; }
  [data-theme="dark"] .gh { background:#161b22; border-color:#30363d; box-shadow:none; }
  [data-theme="dark"] .gh__head { border-bottom-color:#30363d; }
  [data-theme="dark"] .gh__avatar { border-color:#30363d; }
  [data-theme="dark"] .gh__title a { color:#2f81f7; }
  [data-theme="dark"] .gh__desc { color:#8d96a0; }
  [data-theme="dark"] .gh__chip--active   { background:rgba(35,134,54,.16); color:#3fb950; }
  [data-theme="dark"] .gh__chip--archived { background:rgba(248,81,73,.18); color:#f85149; }
  [data-theme="dark"] .gh__chip--lang     { background:#0d1117; color:#e6edf3; border-color:#30363d; }
  [data-theme="dark"] .gh__chip--meta     { background:#0d1117; color:#8d96a0; border-color:#30363d; }
  [data-theme="dark"] .gh__home a { color:#2f81f7; }
  [data-theme="dark"] .gh__stats { background:#30363d; border-bottom-color:#30363d; }
  [data-theme="dark"] .gh__stat { background:#161b22; }
  [data-theme="dark"] .gh__stat:hover { background:#1c222b; }
  [data-theme="dark"] .gh__stat-num { color:#e6edf3; }
  [data-theme="dark"] .gh__stat-label { color:#8d96a0; }
  [data-theme="dark"] .gh__h2 { color:#8d96a0; }
  [data-theme="dark"] .gh__topics { border-bottom-color:#30363d; }
  [data-theme="dark"] .gh__topic { background:rgba(47,129,247,.16); color:#2f81f7; }
  [data-theme="dark"] .gh__dates { border-bottom-color:#30363d; }
  [data-theme="dark"] .gh__dates dt { color:#8d96a0; }
  [data-theme="dark"] .gh__dates dd { color:#e6edf3; }
  [data-theme="dark"] .gh__foot { background:#0d1117; }
  [data-theme="dark"] .gh__foot a { color:#2f81f7; }
</style>
`,N=`{%- comment -%}
  Freshet starter — PokéAPI card. Liquid syntax.
  Bundled rule: \`pokeapi.co\` / \`/api/v2/pokemon/*\`  (inactive by default)
  Try it: activate the rule in Rules tab, then visit
  https://pokeapi.co/api/v2/pokemon/pikachu
{%- endcomment -%}
<div class="pk">
  <header class="pk__head">
    <span class="pk__id">#{{ id | prepend: "0000" | slice: -4, 4 }}</span>
    <h1 class="pk__name">{{ name | capitalize }}</h1>
    <ul class="pk__types">
      {% for t in types %}
      <li class="pk__type" data-type="{{ t.type.name }}">{{ t.type.name }}</li>
      {% endfor %}
    </ul>
  </header>

  <section class="pk__hero">
    <img class="pk__art" src="{{ sprites.other['official-artwork'].front_default }}" alt="{{ name | capitalize }} official artwork" />
    <dl class="pk__facts">
      {%- comment -%} pokeapi returns height in decimetres + weight in hectograms.
      Liquid arithmetic filters convert to m + kg in-template — JSON shapes you
      didn't author still produce sensible UIs. {%- endcomment -%}
      <dt>Height</dt><dd>{{ height | divided_by: 10.0 }} m</dd>
      <dt>Weight</dt><dd>{{ weight | divided_by: 10.0 }} kg</dd>
      <dt>Base XP</dt><dd>{{ base_experience }}</dd>
    </dl>
  </section>

  <section class="pk__stats">
    <h2 class="pk__h2">Base stats</h2>
    <ul class="pk__stat-list">
      {% for s in stats %}
      <li class="pk__stat" data-stat="{{ s.stat.name }}">
        <span class="pk__stat-name">{{ s.stat.name | replace: "-", " " | capitalize }}</span>
        <span class="pk__stat-bar"><span class="pk__stat-fill" style="width: {{ s.base_stat }}%"></span></span>
        <span class="pk__stat-num">{{ s.base_stat }}</span>
      </li>
      {% endfor %}
    </ul>
  </section>

  <section class="pk__abilities">
    <h2 class="pk__h2">Abilities</h2>
    <ul class="pk__ability-list">
      {% for a in abilities %}
      <li class="pk__ability">
        {{ a.ability.name | replace: "-", " " | capitalize }}
        {% if a.is_hidden %}<span class="pk__hidden">hidden</span>{% endif %}
      </li>
      {% endfor %}
    </ul>
  </section>

  {%- comment -%} URL-FROM-ID demo: PokéAPI gives you \`name: "pikachu"\` —
  the template builds the canonical Bulbapedia article URL from it. Same
  pattern as service-health: any ID/name field becomes a navigable link to
  whatever knowledge surface your team agrees on. {%- endcomment -%}
  <footer class="pk__foot">
    <a href="https://bulbapedia.bulbagarden.net/wiki/{{ name | capitalize }}_(Pokémon)" rel="noopener noreferrer">📖 Bulbapedia</a>
    <a href="https://pokeapi.co/api/v2/pokemon-species/{{ id }}/">🧬 Species data</a>
  </footer>
</div>

<style>
  /* Light theme (default) */
  body { background:#f6f8fa; margin:0; padding:24px; font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif; color:#1f2328; }
  .pk { max-width:760px; margin:0 auto; background:#ffffff; border:1px solid #d0d7de; border-radius:14px; overflow:hidden; box-shadow:0 1px 3px rgba(0,0,0,.04); }
  .pk__head { padding:20px 24px 16px; display:flex; align-items:center; gap:12px; flex-wrap:wrap; border-bottom:1px solid #d0d7de; }
  .pk__id { font:600 11px/1 ui-monospace,Menlo,monospace; padding:4px 8px; border-radius:4px; background:#f6f8fa; color:#656d76; border:1px solid #d0d7de; }
  .pk__name { margin:0; font-size:24px; font-weight:700; flex:1 1 auto; letter-spacing:-.01em; }
  .pk__types { list-style:none; margin:0; padding:0; display:flex; gap:6px; }
  .pk__type { font:700 10px/1 ui-monospace,Menlo,monospace; text-transform:uppercase; letter-spacing:.08em; padding:6px 10px; border-radius:999px; color:#fff; background:#656d76; }
  .pk__type[data-type="electric"] { background:#f7d02c; color:#3a2f00; }
  .pk__type[data-type="fire"]     { background:#ee8130; }
  .pk__type[data-type="water"]    { background:#6390f0; }
  .pk__type[data-type="grass"]    { background:#7ac74c; }
  .pk__type[data-type="normal"]   { background:#a8a77a; }
  .pk__type[data-type="flying"]   { background:#a98ff3; }
  .pk__type[data-type="psychic"]  { background:#f95587; }
  .pk__type[data-type="ice"]      { background:#96d9d6; color:#1f3132; }
  .pk__type[data-type="dragon"]   { background:#6f35fc; }
  .pk__type[data-type="dark"]     { background:#705746; }
  .pk__type[data-type="fairy"]    { background:#d685ad; }
  .pk__type[data-type="ground"]   { background:#e2bf65; color:#3a2e00; }
  .pk__type[data-type="rock"]     { background:#b6a136; }
  .pk__type[data-type="bug"]      { background:#a6b91a; }
  .pk__type[data-type="ghost"]    { background:#735797; }
  .pk__type[data-type="steel"]    { background:#b7b7ce; color:#2c2c3a; }
  .pk__type[data-type="poison"]   { background:#a33ea1; }
  .pk__type[data-type="fighting"] { background:#c22e28; }

  .pk__hero { display:grid; grid-template-columns:200px 1fr; gap:24px; padding:24px; align-items:center; border-bottom:1px solid #d0d7de; }
  .pk__art { width:100%; height:auto; max-width:200px; }
  .pk__facts { display:grid; grid-template-columns:auto 1fr; gap:6px 16px; margin:0; font-size:14px; }
  .pk__facts dt { color:#656d76; font-weight:500; }
  .pk__facts dd { margin:0; color:#1f2328; font-weight:600; }

  .pk__h2 { margin:0 0 12px; font:600 11px/1 ui-monospace,Menlo,monospace; color:#656d76; text-transform:uppercase; letter-spacing:.06em; }

  .pk__stats { padding:20px 24px; border-bottom:1px solid #d0d7de; }
  .pk__stat-list { list-style:none; margin:0; padding:0; display:grid; gap:8px; }
  .pk__stat { display:grid; grid-template-columns:130px 1fr 36px; align-items:center; gap:12px; font-size:13px; }
  .pk__stat-name { color:#656d76; }
  .pk__stat-bar { height:8px; background:#f6f8fa; border:1px solid #d0d7de; border-radius:999px; overflow:hidden; }
  .pk__stat-fill { display:block; height:100%; background:#0969da; border-radius:999px; transition:width 200ms ease; }
  .pk__stat[data-stat="hp"]              .pk__stat-fill { background:#1a7f37; }
  .pk__stat[data-stat="attack"]          .pk__stat-fill { background:#cf222e; }
  .pk__stat[data-stat="defense"]         .pk__stat-fill { background:#9a6700; }
  .pk__stat[data-stat="special-attack"]  .pk__stat-fill { background:#8250df; }
  .pk__stat[data-stat="special-defense"] .pk__stat-fill { background:#0969da; }
  .pk__stat[data-stat="speed"]           .pk__stat-fill { background:#bf3989; }
  .pk__stat-num { text-align:right; font:600 13px/1.2 ui-monospace,Menlo,monospace; color:#1f2328; }

  .pk__abilities { padding:20px 24px; border-bottom:1px solid #d0d7de; }
  .pk__ability-list { list-style:none; margin:0; padding:0; display:flex; flex-wrap:wrap; gap:8px; }
  .pk__ability { background:#f6f8fa; border:1px solid #d0d7de; padding:6px 12px; border-radius:6px; font-size:13px; display:inline-flex; align-items:center; gap:6px; }
  .pk__hidden { font:600 9px/1 ui-monospace,Menlo,monospace; text-transform:uppercase; letter-spacing:.06em; padding:2px 6px; background:#fff8c5; color:#9a6700; border-radius:3px; }

  .pk__foot { display:flex; gap:18px; padding:14px 24px; background:#f6f8fa; }
  .pk__foot a { color:#0969da; text-decoration:none; font-size:13px; }
  .pk__foot a:hover { text-decoration:underline; }

  /* Dark theme — applied when Freshet sets data-theme="dark" on <html>. */
  [data-theme="dark"] body { background:#0d1117; color:#e6edf3; }
  [data-theme="dark"] .pk { background:#161b22; border-color:#30363d; box-shadow:none; }
  [data-theme="dark"] .pk__head { border-bottom-color:#30363d; }
  [data-theme="dark"] .pk__id { background:#0d1117; color:#8d96a0; border-color:#30363d; }
  [data-theme="dark"] .pk__hero { border-bottom-color:#30363d; }
  [data-theme="dark"] .pk__facts dt { color:#8d96a0; }
  [data-theme="dark"] .pk__facts dd { color:#e6edf3; }
  [data-theme="dark"] .pk__h2 { color:#8d96a0; }
  [data-theme="dark"] .pk__stats { border-bottom-color:#30363d; }
  [data-theme="dark"] .pk__stat-name { color:#8d96a0; }
  [data-theme="dark"] .pk__stat-bar { background:#0d1117; border-color:#30363d; }
  [data-theme="dark"] .pk__stat-num { color:#e6edf3; }
  [data-theme="dark"] .pk__stat[data-stat="hp"]              .pk__stat-fill { background:#3fb950; }
  [data-theme="dark"] .pk__stat[data-stat="attack"]          .pk__stat-fill { background:#f85149; }
  [data-theme="dark"] .pk__stat[data-stat="defense"]         .pk__stat-fill { background:#d29922; }
  [data-theme="dark"] .pk__stat[data-stat="special-attack"]  .pk__stat-fill { background:#a371f7; }
  [data-theme="dark"] .pk__stat[data-stat="special-defense"] .pk__stat-fill { background:#2f81f7; }
  [data-theme="dark"] .pk__stat[data-stat="speed"]           .pk__stat-fill { background:#db61a2; }
  [data-theme="dark"] .pk__abilities { border-bottom-color:#30363d; }
  [data-theme="dark"] .pk__ability { background:#0d1117; border-color:#30363d; }
  [data-theme="dark"] .pk__hidden { background:rgba(210,153,34,.18); color:#d29922; }
  [data-theme="dark"] .pk__foot { background:#0d1117; }
  [data-theme="dark"] .pk__foot a { color:#2f81f7; }
</style>
`,D=`{%- comment -%}
  Freshet starter — REST Countries card. Liquid syntax.
  Bundled rule: \`restcountries.com\` / \`/v3.1/name/*\`  (inactive by default)
  Try it: activate the rule in Rules tab, then visit
  https://restcountries.com/v3.1/name/japan

  REST Countries always returns an ARRAY of matches. Freshet's engine exposes
  array-root JSON as \`items\`, so the first line below grabs the first match
  and aliases it as \`c\` for the rest of the template.
{%- endcomment -%}
{% assign c = items[0] %}
<div class="ct">
  <header class="ct__head">
    <span class="ct__flag-emoji" aria-hidden="true">{{ c.flag }}</span>
    <div class="ct__heading">
      <h1 class="ct__name">{{ c.name.common }}</h1>
      {% if c.name.official != c.name.common %}<p class="ct__official">{{ c.name.official }}</p>{% endif %}
      {% for entry in c.name.nativeName %}
        <p class="ct__native"><span class="ct__native-code">{{ entry[0] | upcase }}</span> {{ entry[1].common }}</p>
      {% endfor %}
    </div>
    <img class="ct__flag-img" src="{{ c.flags.svg }}" alt="{{ c.flags.alt }}" />
  </header>

  <section class="ct__row">
    <div class="ct__metric">
      <span class="ct__metric-label">Capital</span>
      <span class="ct__metric-value">{{ c.capital | first }}</span>
    </div>
    <div class="ct__metric">
      <span class="ct__metric-label">Population</span>
      <span class="ct__metric-value">{{ c.population | num }}</span>
    </div>
    <div class="ct__metric">
      <span class="ct__metric-label">Area</span>
      <span class="ct__metric-value">{{ c.area | num }} <span class="ct__metric-unit">km²</span></span>
    </div>
  </section>

  <section class="ct__panel">
    <h2 class="ct__h2">Region</h2>
    <ul class="ct__chips">
      <li class="ct__chip">{{ c.region }}</li>
      {% if c.subregion != blank %}<li class="ct__chip ct__chip--muted">{{ c.subregion }}</li>{% endif %}
      {% for cont in c.continents %}<li class="ct__chip ct__chip--muted">{{ cont }}</li>{% endfor %}
    </ul>
  </section>

  <section class="ct__panel">
    <h2 class="ct__h2">Languages</h2>
    <ul class="ct__chips">
      {% for lang in c.languages %}
      <li class="ct__chip"><span class="ct__chip-key">{{ lang[0] | upcase }}</span> {{ lang[1] }}</li>
      {% endfor %}
    </ul>
  </section>

  <section class="ct__panel">
    <h2 class="ct__h2">Currencies</h2>
    <ul class="ct__chips">
      {% for cur in c.currencies %}
      <li class="ct__chip"><span class="ct__chip-key">{{ cur[0] }}</span> {{ cur[1].name }} ({{ cur[1].symbol }})</li>
      {% endfor %}
    </ul>
  </section>

  <section class="ct__panel">
    <h2 class="ct__h2">Timezones</h2>
    <ul class="ct__chips">
      {% for tz in c.timezones %}<li class="ct__chip ct__chip--mono">{{ tz }}</li>{% endfor %}
    </ul>
  </section>

  {%- comment -%} URL-FROM-ID demo: build the canonical Wikipedia article URL
  from \`c.name.common\`. Same trick as the SRE templates and pokemon — random
  API field becomes a navigable link. {%- endcomment -%}
  <footer class="ct__foot">
    <a href="https://en.wikipedia.org/wiki/{{ c.name.common | replace: ' ', '_' }}" rel="noopener noreferrer">📖 Wikipedia</a>
    <a href="https://restcountries.com/v3.1/alpha/{{ c.cca3 }}">🌍 Full record (cca3 lookup)</a>
  </footer>
</div>

<style>
  /* Light theme (default) */
  body { background:#f6f8fa; margin:0; padding:24px; font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif; color:#1f2328; }
  .ct { max-width:780px; margin:0 auto; background:#ffffff; border:1px solid #d0d7de; border-radius:12px; overflow:hidden; box-shadow:0 1px 3px rgba(0,0,0,.04); }
  .ct__head { display:grid; grid-template-columns:auto 1fr auto; gap:20px; padding:24px; align-items:center; border-bottom:1px solid #d0d7de; }
  .ct__flag-emoji { font-size:64px; line-height:1; }
  .ct__heading { min-width:0; }
  .ct__name { margin:0 0 4px; font-size:26px; font-weight:700; letter-spacing:-.01em; }
  .ct__official { margin:0 0 4px; color:#656d76; font-size:13px; }
  .ct__native { margin:2px 0; font-size:13px; color:#1f2328; }
  .ct__native-code { display:inline-block; min-width:32px; font:600 10px/1 ui-monospace,Menlo,monospace; padding:2px 6px; border-radius:3px; background:#f6f8fa; color:#656d76; border:1px solid #d0d7de; margin-right:6px; }
  .ct__flag-img { width:96px; height:auto; border:1px solid #d0d7de; border-radius:4px; }

  .ct__row { display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:#d0d7de; border-bottom:1px solid #d0d7de; }
  .ct__metric { background:#ffffff; padding:16px 20px; display:flex; flex-direction:column; gap:4px; }
  .ct__metric-label { font:600 10px/1 ui-monospace,Menlo,monospace; color:#656d76; text-transform:uppercase; letter-spacing:.06em; }
  .ct__metric-value { font:600 20px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; color:#1f2328; }
  .ct__metric-unit { font-size:13px; color:#656d76; font-weight:500; }

  .ct__panel { padding:16px 24px; border-bottom:1px solid #d0d7de; }
  .ct__h2 { margin:0 0 10px; font:600 11px/1 ui-monospace,Menlo,monospace; color:#656d76; text-transform:uppercase; letter-spacing:.06em; }
  .ct__chips { list-style:none; margin:0; padding:0; display:flex; flex-wrap:wrap; gap:6px; }
  .ct__chip { background:#f6f8fa; border:1px solid #d0d7de; padding:5px 10px; border-radius:999px; font-size:13px; display:inline-flex; align-items:center; gap:6px; }
  .ct__chip--muted { color:#656d76; }
  .ct__chip--mono { font-family:ui-monospace,Menlo,monospace; font-size:12px; }
  .ct__chip-key { font:600 10px/1 ui-monospace,Menlo,monospace; padding:2px 6px; border-radius:3px; background:rgba(9,105,218,.08); color:#0969da; }

  .ct__foot { display:flex; gap:18px; padding:14px 24px; background:#f6f8fa; }
  .ct__foot a { color:#0969da; text-decoration:none; font-size:13px; }
  .ct__foot a:hover { text-decoration:underline; }

  /* Dark theme — applied when Freshet sets data-theme="dark" on <html>. */
  [data-theme="dark"] body { background:#0d1117; color:#e6edf3; }
  [data-theme="dark"] .ct { background:#161b22; border-color:#30363d; box-shadow:none; }
  [data-theme="dark"] .ct__head { border-bottom-color:#30363d; }
  [data-theme="dark"] .ct__official { color:#8d96a0; }
  [data-theme="dark"] .ct__native { color:#e6edf3; }
  [data-theme="dark"] .ct__native-code { background:#0d1117; color:#8d96a0; border-color:#30363d; }
  [data-theme="dark"] .ct__flag-img { border-color:#30363d; }
  [data-theme="dark"] .ct__row { background:#30363d; border-bottom-color:#30363d; }
  [data-theme="dark"] .ct__metric { background:#161b22; }
  [data-theme="dark"] .ct__metric-label { color:#8d96a0; }
  [data-theme="dark"] .ct__metric-value { color:#e6edf3; }
  [data-theme="dark"] .ct__metric-unit { color:#8d96a0; }
  [data-theme="dark"] .ct__panel { border-bottom-color:#30363d; }
  [data-theme="dark"] .ct__h2 { color:#8d96a0; }
  [data-theme="dark"] .ct__chip { background:#0d1117; border-color:#30363d; }
  [data-theme="dark"] .ct__chip--muted { color:#8d96a0; }
  [data-theme="dark"] .ct__chip-key { background:rgba(47,129,247,.16); color:#2f81f7; }
  [data-theme="dark"] .ct__foot { background:#0d1117; }
  [data-theme="dark"] .ct__foot a { color:#2f81f7; }
</style>
`,B=`{
  "name": "Payments",
  "slug": "payments",
  "description": "Charge processing, refunds, payout reconciliation.",
  "status": "degraded",
  "uptime30d": 99.92,
  "lastIncidentAt": "2026-04-18T14:22:00Z",
  "oncall": {
    "name": "Priya Raman",
    "handle": "@priya"
  },
  "owners": ["payments-platform", "billing-infra"],
  "dependencies": [
    { "name": "Postgres (primary)", "status": "operational" },
    { "name": "Stripe API", "status": "operational" },
    { "name": "Redis (rate-limit)", "status": "degraded" },
    { "name": "Kafka (events)", "status": "operational" }
  ],
  "recentIncidents": [
    {
      "id": "INC-2026-001",
      "title": "Elevated 5xx on /charge — Redis rate-limiter saturating",
      "severity": "sev-2",
      "openedAt": "2026-04-18T14:22:00Z",
      "resolvedAt": null
    },
    {
      "id": "INC-2026-000",
      "title": "Stripe webhook delivery latency spike",
      "severity": "sev-3",
      "openedAt": "2026-04-11T09:08:00Z",
      "resolvedAt": "2026-04-11T10:42:00Z"
    }
  ],
  "repo": "example/payments-service"
}
`,H=`{
  "id": "INC-2026-001",
  "title": "Elevated 5xx on /charge — Redis rate-limiter saturating",
  "severity": "sev-2",
  "status": "monitoring",
  "openedAt": "2026-04-18T14:22:00Z",
  "resolvedAt": null,
  "service": {
    "name": "Payments",
    "slug": "payments"
  },
  "oncall": {
    "name": "Priya Raman",
    "handle": "@priya"
  },
  "summary": "Redis rate-limiter cluster CPU climbed past 92% sustaining ~14k RPS over baseline. Surfaces as intermittent 503s on POST /charge with \`rate_limit_unavailable\` reason. Mitigated by failing open on rate-limit lookups; root cause under investigation.",
  "impact": "Approximately 0.4% of /charge requests returning 503 between 14:22 and 14:51 UTC. No data loss. Retried client requests succeeding within 2s.",
  "timeline": [
    { "at": "2026-04-18T14:22:00Z", "author": "alertmanager", "kind": "alert",   "message": "5xx-rate alert fired on payments-api (threshold 1.0%, observed 4.3%)." },
    { "at": "2026-04-18T14:24:30Z", "author": "@priya",       "kind": "ack",     "message": "Acknowledged. Investigating — looks like rate-limiter saturation, not Stripe." },
    { "at": "2026-04-18T14:31:10Z", "author": "@priya",       "kind": "update",  "message": "Confirmed Redis CPU at 92% on the rate-limit cluster. Failing open on rate-limit lookups via runtime flag." },
    { "at": "2026-04-18T14:34:45Z", "author": "deploybot",    "kind": "deploy",  "message": "Flag \`rate_limit.fail_open\` rolled to 100% in production." },
    { "at": "2026-04-18T14:51:02Z", "author": "@priya",       "kind": "update",  "message": "5xx rate back at baseline. Monitoring for the next 30 min before resolving." }
  ],
  "relatedIncidents": [
    {
      "id": "INC-2026-000",
      "title": "Stripe webhook delivery latency spike"
    }
  ]
}
`,$=`{
  "full_name": "facebook/react",
  "description": "The library for web and native user interfaces.",
  "html_url": "https://github.com/facebook/react",
  "homepage": "https://react.dev",
  "stargazers_count": 234567,
  "forks_count": 47890,
  "subscribers_count": 6700,
  "open_issues_count": 825,
  "language": "JavaScript",
  "license": { "name": "MIT License", "spdx_id": "MIT" },
  "default_branch": "main",
  "created_at": "2013-05-24T16:15:54Z",
  "pushed_at": "2026-04-15T23:00:00Z",
  "topics": ["react", "javascript", "frontend", "library", "ui"],
  "owner": {
    "login": "facebook",
    "avatar_url": "https://avatars.githubusercontent.com/u/69631?v=4"
  },
  "archived": false
}
`,J=`{
  "id": 25,
  "name": "pikachu",
  "height": 4,
  "weight": 60,
  "base_experience": 112,
  "types": [
    { "slot": 1, "type": { "name": "electric", "url": "https://pokeapi.co/api/v2/type/13/" } }
  ],
  "abilities": [
    { "is_hidden": false, "slot": 1, "ability": { "name": "static",       "url": "https://pokeapi.co/api/v2/ability/9/" } },
    { "is_hidden": true,  "slot": 3, "ability": { "name": "lightning-rod", "url": "https://pokeapi.co/api/v2/ability/31/" } }
  ],
  "stats": [
    { "base_stat": 35,  "effort": 0, "stat": { "name": "hp",              "url": "" } },
    { "base_stat": 55,  "effort": 0, "stat": { "name": "attack",          "url": "" } },
    { "base_stat": 40,  "effort": 0, "stat": { "name": "defense",         "url": "" } },
    { "base_stat": 50,  "effort": 0, "stat": { "name": "special-attack",  "url": "" } },
    { "base_stat": 50,  "effort": 0, "stat": { "name": "special-defense", "url": "" } },
    { "base_stat": 90,  "effort": 2, "stat": { "name": "speed",           "url": "" } }
  ],
  "sprites": {
    "front_default": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png",
    "other": {
      "official-artwork": {
        "front_default": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png"
      }
    }
  },
  "species": {
    "name": "pikachu",
    "url": "https://pokeapi.co/api/v2/pokemon-species/25/"
  }
}
`,Z=`[
  {
    "name": {
      "common": "Japan",
      "official": "Japan",
      "nativeName": {
        "jpn": { "official": "日本", "common": "日本" }
      }
    },
    "tld": [".jp", ".みんな"],
    "cca2": "JP",
    "cca3": "JPN",
    "ccn3": "392",
    "independent": true,
    "status": "officially-assigned",
    "unMember": true,
    "currencies": {
      "JPY": { "name": "Japanese yen", "symbol": "¥" }
    },
    "capital": ["Tokyo"],
    "region": "Asia",
    "subregion": "Eastern Asia",
    "languages": { "jpn": "Japanese" },
    "latlng": [36, 138],
    "landlocked": false,
    "borders": [],
    "area": 377930,
    "population": 125836021,
    "flag": "🇯🇵",
    "flags": {
      "png": "https://flagcdn.com/w320/jp.png",
      "svg": "https://flagcdn.com/jp.svg",
      "alt": "The flag of Japan features a crimson-red circle at the center of a white field."
    },
    "continents": ["Asia"],
    "timezones": ["UTC+09:00"]
  }
]
`,q="#16a34a",W="#dc2626";function G(e){return e==="pj:rendered"?{text:"✓",color:q}:{text:"!",color:W}}async function V(){await Y(),await Q();try{await U(chrome.storage)}catch(e){console.warn("[freshet] rules enabled→active migration skipped:",e)}await K()}const f=[{name:"service-health",template:j,sample:B,rule:{hostPattern:"mattaltermatt.github.io",pathPattern:"/freshet/examples/services/*",templateName:"service-health",variables:{env:"production"},active:!0,exampleUrl:"https://mattaltermatt.github.io/freshet/examples/services/payments.json"}},{name:"incident-detail",template:O,sample:H,rule:{hostPattern:"mattaltermatt.github.io",pathPattern:"/freshet/examples/incidents/*",templateName:"incident-detail",variables:{},active:!0,exampleUrl:"https://mattaltermatt.github.io/freshet/examples/incidents/INC-2026-001.json"}},{name:"github-repo",template:F,sample:$,rule:{hostPattern:"api.github.com",pathPattern:"/repos/*/*",templateName:"github-repo",variables:{},active:!1,exampleUrl:"https://api.github.com/repos/facebook/react"}},{name:"pokemon",template:N,sample:J,rule:{hostPattern:"pokeapi.co",pathPattern:"/api/v2/pokemon/*",templateName:"pokemon",variables:{},active:!1,exampleUrl:"https://pokeapi.co/api/v2/pokemon/pikachu"}},{name:"country",template:D,sample:Z,rule:{hostPattern:"restcountries.com",pathPattern:"/v3.1/name/*",templateName:"country",variables:{},active:!1,exampleUrl:"https://restcountries.com/v3.1/name/japan"}}];async function K(){const e=await u(chrome.storage),[a,t]=await Promise.all([e.getTemplates(),e.getRules()]);if(Object.keys(a).length>0||t.length>0)return;const n=Object.fromEntries(f.map(o=>[o.name,o.sample]));await chrome.storage.local.set({pj_storage_area:"local",pj_sample_json:n});const s=await u(chrome.storage);await s.setTemplates(Object.fromEntries(f.map(o=>[o.name,o.template]))),await s.setRules(f.map((o,r)=>({...o.rule,id:`starter-${o.name}-${r}`,isExample:!0}))),await s.setSchemaVersion(2)}async function Y(){try{const e=await chrome.storage.sync.get(["rules","templates","hostSkipList"]);A(e)>P&&await C(chrome.storage)}catch(e){console.warn("[freshet] storage-area migration skipped:",e)}}async function Q(){try{const e=await u(chrome.storage);if(await e.getSchemaVersion()!==void 0)return;const t=await E(e);t.ok||console.warn("[freshet] template migration rolled back; failing template IDs:",t.failed)}catch(e){console.warn("[freshet] schema migration skipped:",e)}}V();chrome.commands.onCommand.addListener(e=>{e==="toggle-raw"&&chrome.tabs.query({active:!0,currentWindow:!0},a=>{var n;const t=(n=a[0])==null?void 0:n.id;t!==void 0&&chrome.tabs.sendMessage(t,{kind:"pj:toggle-raw"}).catch(()=>{})})});const _=new Map;chrome.runtime.onMessage.addListener((e,a)=>{var n,s;if(typeof e!="object"||e===null)return;const t=e.kind;if(t==="pj:open-options"){const o=e.hash,r=chrome.runtime.getURL("src/options/options.html")+(typeof o=="string"?o:"");chrome.tabs.create({url:r});return}if(t==="pj:rendered"||t==="pj:render-error"){const o=(n=a.tab)==null?void 0:n.id;if(o===void 0)return;const r=G(t);chrome.action.setBadgeText({tabId:o,text:r.text}),chrome.action.setBadgeBackgroundColor({tabId:o,color:r.color}),(s=a.tab)!=null&&s.url&&_.set(o,a.tab.url)}});chrome.tabs.onUpdated.addListener((e,a)=>{a.status==="loading"&&(a.url&&a.url===_.get(e)||(_.delete(e),chrome.action.setBadgeText({tabId:e,text:""})))});chrome.tabs.onRemoved.addListener(e=>{_.delete(e)});
